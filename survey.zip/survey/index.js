
Survey
    .StylesManager
    .applyTheme("modern");

var surveyValueChanged = function (sender, options) {
    var el = document.getElementById(options.name);
    if (el) {
        el.value = options.value;
    }
};

var json = {
    type: "survey",
    title: "Film feedback form",
    description: "Thank you for participating in the film festival!Please fill out this short survey so we can record your feedback. ",
    questions: [
        {
            type: "text",
            name: "name",
            title: "What film did you watch?",
            isRequired:true,
            attributes:null
        },  {
            
            type: "radiogroup",
            name: "raiting",
            title: "How would you rate the film? (1 - Very bad, 5 Very good)",
            isRequired: true,
            colCount: 4,
            choices: [
                "1",
                "2",
                "3",
                "4",
                "5"
            ]
        }
    ]
};
          

window.survey = new Survey.Model(json);

survey
    .onComplete
    .add(function (sender) {
        document
            .querySelector('#surveyResult')
            .textContent = "Result JSON:\n" + JSON.stringify(sender.data, null, 3);
    });

survey.data = {
    name: ' ',
    raiting: ['1']

};

$("#surveyElement").Survey({model: survey, onValueChanged: surveyValueChanged});;